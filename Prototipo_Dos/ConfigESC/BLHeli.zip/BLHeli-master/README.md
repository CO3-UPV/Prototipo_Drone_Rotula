This tree contains BLHeli code for sensorless brushless motor electronic speed control (ESC) boards.  
  
To view and use the files, click the "Clone or download" button on this page,  
and then select "Download ZIP" to download the repository to your computer.  
  
For flashing and configuration, download the BLHeliSuite PC software:  
https://www.mediafire.com/folder/dx6kfaasyo24l/BLHeliSuite  
  
For more information, check out these threads:  
https://www.rcgroups.com/forums/showthread.php?2640796 (for BLHeli_S)  
http://www.rcgroups.com/forums/showthread.php?t=2136895 (for BLHeli)  
  
And look in the "BLHeli_32 ARM" folder for info on BLHeli_32.

October 2018,
Steffen Skaug
